import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, Button, FlatList, Alert } from 'react-native';
import axios from 'axios';

export default function MultiplayerScreen() {
  const [username, setUsername] = useState('');
  const [word, setWord] = useState('');
  const [guesses, setGuesses] = useState([]);
  const [guess, setGuess] = useState('');

  const handleStartGame = () => {
    axios.post('http://192.168.1.4:3000/startMultiplayer', { username })
      .then(response => setWord(response.data.word))
      .catch(error => console.error(error));
  };

  const handleGuess = () => {
    setGuesses([...guesses, guess]);
    if (guess.toUpperCase() === word.toUpperCase()) {
      Alert.alert('Congratulations!', 'You guessed the word!');
    } else {
      Alert.alert('Try again!', 'Incorrect guess.');
    }
    setGuess('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Multiplayer Game</Text>
      <TextInput
        value={username}
        onChangeText={setUsername}
        placeholder="Enter your username"
        style={styles.input}
      />
      <Button title="Start Game" onPress={handleStartGame} />
      <TextInput
        value={guess}
        onChangeText={setGuess}
        placeholder="Enter your guess"
        style={styles.input}
      />
      <Button title="Submit Guess" onPress={handleGuess} />
      <FlatList
        data={guesses}
        renderItem={({ item }) => <Text style={styles.guess}>{item}</Text>}
        keyExtractor={(item, index) => index.toString()}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f8f8',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    width: 250,
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
  guess: {
    fontSize: 18,
    color: '#333',
    marginTop: 10,
  },
});
