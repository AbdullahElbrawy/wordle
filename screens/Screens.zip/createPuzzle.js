import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Alert } from 'react-native';
import axios from 'axios';

export default function CreatePuzzleScreen() {
  const [puzzle, setPuzzle] = useState('');

  const handleSubmit = () => {
    axios.post('http://192.168.1.4:3000/createPuzzle', { username: 'User', puzzle })
      .then(response => {
        if (response.data.success) {
          Alert.alert('Puzzle created successfully!');
        }
      })
      .catch(error => {
        Alert.alert('Error creating puzzle', error.message);
      });
  };

  return (
    <View style={styles.container}>
      <TextInput
        value={puzzle}
        onChangeText={setPuzzle}
        placeholder="Enter your puzzle"
        style={styles.input}
      />
      <Button title="Create Puzzle" onPress={handleSubmit} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f8f8',
    padding: 20,
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    width: 250,
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
});
