import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import ARKit from 'react-native-arkit';

export default function ARScreen() {
  const [word, setWord] = useState('');

  useEffect(() => {
    // Fetch word related to the user's current location
    fetch(`http://192.168.1.100:30000/word?geolocation=true`)
      .then(response => response.json())
      .then(data => setWord(data.word));
  }, []);

  return (
    <View style={styles.container}>
      <ARKit style={styles.arView}>
        <ARKit.Text
          text={word}
          position={{ x: 0, y: 0.1, z: -0.5 }}
          font={{ size: 0.1, depth: 0.05 }}
          material={{
            diffuse: {
              color: '#ffffff',
            },
          }}
        />
      </ARKit>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  arView: {
    flex: 1,
  },
});
