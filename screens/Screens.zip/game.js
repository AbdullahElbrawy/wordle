import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Alert, TouchableOpacity } from 'react-native';
import WordInput from './wordInput';
import WordDisplay from './wordDisplay';
import axios from 'axios';

export default function GameScreen({ route }) {
  const { lang } = route.params;
  const [word, setWord] = useState('');
  const [attempts, setAttempts] = useState([]);
  const [hints, setHints] = useState({ revealLetter: 3, eliminateWrong: 3 });
  const [revealedLetters, setRevealedLetters] = useState([]);
  const [incorrectLetters, setIncorrectLetters] = useState([]);

  useEffect(() => {
    axios.get(`http://192.168.1.4:3000/word?lang=${lang}&difficulty=medium`)
      .then(response => setWord(response.data.word))
      .catch(error => console.error(error));
  }, [lang]);

  const handleHint = (hintType) => {
    axios.post('http://192.168.1.4:3000/useHint', { username: 'User', hintType })
      .then(response => {
        if (response.data.success) {
          setHints({ ...hints, [hintType]: response.data.hintsLeft });
          if (hintType === 'revealLetter') {
            revealLetter();
          } else if (hintType === 'eliminateWrong') {
            eliminateWrongLetters();
          }
        } else {
          Alert.alert('No hints left');
        }
      })
      .catch(error => {
        console.error(error);
        Alert.alert('Error', 'An error occurred while using the hint');
      });
  };

  const revealLetter = () => {
    const unrevealedIndexes = word.split('').map((letter, index) => (
      revealedLetters.includes(index) ? null : index
    )).filter(index => index !== null);

    if (unrevealedIndexes.length > 0) {
      const randomIndex = unrevealedIndexes[Math.floor(Math.random() * unrevealedIndexes.length)];
      setRevealedLetters([...revealedLetters, randomIndex]);
    }
  };

  const eliminateWrongLetters = () => {
    const allLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    const wordLetters = word.split('');
    const wrongLetters = allLetters.filter(letter => !wordLetters.includes(letter));
    const numberOfLettersToRemove = Math.min(3, wrongLetters.length);
    const lettersToRemove = [];

    while (lettersToRemove.length < numberOfLettersToRemove) {
      const randomIndex = Math.floor(Math.random() * wrongLetters.length);
      const letter = wrongLetters[randomIndex];
      if (!lettersToRemove.includes(letter)) {
        lettersToRemove.push(letter);
      }
    }

    setIncorrectLetters([...incorrectLetters, ...lettersToRemove]);
    Alert.alert('Eliminate Wrong Letters hint used', `Removed: ${lettersToRemove.join(', ')}`);
  };

  const handleAttempt = (input) => {
    setAttempts([...attempts, input]);
    if (input === word) {
      Alert.alert('Congratulations!', 'You guessed the word!');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Wordle Game</Text>
      <WordDisplay word={word} attempts={attempts} revealedLetters={revealedLetters} incorrectLetters={incorrectLetters} />
      <WordInput wordLength={word.length} onSubmit={handleAttempt} />
      <View style={styles.hintsContainer}>
        <TouchableOpacity style={styles.button} onPress={() => handleHint('revealLetter')}>
          <Text style={styles.buttonText}>Reveal Letter ({hints.revealLetter})</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleHint('eliminateWrong')}>
          <Text style={styles.buttonText}>Eliminate Wrong ({hints.eliminateWrong})</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f0f0f0',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 40,
  },
  hintsContainer: {
    flexDirection: 'column',
    marginTop: 20,
    width: '100%'
  },
  button: {
    backgroundColor: '#6200ea',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25,
    marginVertical: 10,
    marginHorizontal: 'auto',
    width: '80%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
