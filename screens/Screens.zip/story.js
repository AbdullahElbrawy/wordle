import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, Button, Alert } from 'react-native';
import axios from 'axios';

export default function StoryScreen() {
  const [story, setStory] = useState({ story: '', word: '' });
  const [part, setPart] = useState(1);
  const [input, setInput] = useState('');

  useEffect(() => {
    axios.get(`http://192.168.1.4:3000/story?id=1&part=${part}`)
      .then(response => setStory(response.data))
      .catch(error => console.error(error));
  }, [part]);

  const handleSubmit = () => {
    if (input.toUpperCase() === story.word) {
      setPart(part + 1);
      setInput('');
    } else {
      Alert.alert('Wrong guess, try again.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.story}>{story.story}</Text>
      <TextInput
        value={input}
        onChangeText={setInput}
        maxLength={story.word ? story.word.length : 0}
        placeholder="Enter your guess"
        style={styles.input}
      />
      <Button title="Submit" onPress={handleSubmit} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f8f8',
    padding: 20,
  },
  story: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    width: 250,
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
});
